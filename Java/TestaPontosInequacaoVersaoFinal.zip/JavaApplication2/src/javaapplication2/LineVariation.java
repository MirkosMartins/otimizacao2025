package javaapplication2;

public class LineVariation {
    int lineIndex;
    double variation;

    public LineVariation(int lineIndex, double variation) {
        this.lineIndex = lineIndex;
        this.variation = variation;
    }
}