package javaapplication2;

public class Line {
    double a, b;
    int x1, y1, x2, y2;
    String type;
    String detectedType; 
    boolean isTypeValid;
    boolean isVertical;
    boolean isHorizontal;
    private static final double TOLERANCE = 0.0001;

    public Line(int x1, int y1, int x2, int y2, String type) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        this.type = type != null ? type.trim() : "";
        this.isVertical = x1 == x2;
        this.isHorizontal = y1 == y2;

        if (isVertical) {
            this.a = Double.POSITIVE_INFINITY;
            this.b = x1;
        } else if (isHorizontal) {
            this.a = 0;
            this.b = y1;
        } else {
            this.a = (double)(y2 - y1) / (x2 - x1);
            this.b = y1 - this.a * x1;
        }
        this.isTypeValid = validateLineType();
        if (this.type.isEmpty()) {
            this.type = detectedType; 
        }
    }

    private boolean validateLineType() {
        if (type.isEmpty()) {
            if (isVertical) {
                double expectedX = b;
                if (Math.abs(x1 - expectedX) < TOLERANCE && Math.abs(x2 - expectedX) < TOLERANCE) {
                    detectedType = "=";
                    return true;
                } else if (x1 >= expectedX && x2 >= expectedX) {
                    detectedType = ">=";
                    return true;
                } else if (x1 <= expectedX && x2 <= expectedX) {
                    detectedType = "<=";
                    return true;
                } else if (x1 > expectedX && x2 > expectedX) {
                    detectedType = ">";
                    return true;
                } else if (x1 < expectedX && x2 < expectedX) {
                    detectedType = "<";
                    return true;
                }
            } else if (isHorizontal) {
                double expectedY = b;
                if (Math.abs(y1 - expectedY) < TOLERANCE && Math.abs(y2 - expectedY) < TOLERANCE) {
                    detectedType = "=";
                    return true;
                } else if (y1 >= expectedY && y2 >= expectedY) {
                    detectedType = ">=";
                    return true;
                } else if (y1 <= expectedY && y2 <= expectedY) {
                    detectedType = "<=";
                    return true;
                } else if (y1 > expectedY && y2 > expectedY) {
                    detectedType = ">";
                    return true;
                } else if (y1 < expectedY && y2 < expectedY) {
                    detectedType = "<";
                    return true;
                }
            } else {
                double y1Expected = a * x1 + b;
                double y2Expected = a * x2 + b;
                if (Math.abs(y1 - y1Expected) < TOLERANCE && Math.abs(y2 - y2Expected) < TOLERANCE) {
                    detectedType = "=";
                    return true;
                } else if (y1 >= y1Expected && y2 >= y2Expected) {
                    detectedType = ">=";
                    return true;
                } else if (y1 <= y1Expected && y2 <= y2Expected) {
                    detectedType = "<=";
                    return true;
                } else if (y1 > y1Expected && y2 > y2Expected) {
                    detectedType = ">";
                    return true;
                } else if (y1 < y1Expected && y2 < y2Expected) {
                    detectedType = "<";
                    return true;
                }
            }
            detectedType = "="; 
            return false;
        } else {
            if (type.equals("=")) {
                if (isVertical) {
                    return Math.abs(x1 - b) < TOLERANCE && Math.abs(x2 - b) < TOLERANCE;
                } else if (isHorizontal) {
                    return Math.abs(y1 - b) < TOLERANCE && Math.abs(y2 - b) < TOLERANCE;
                } else {
                    double y1Expected = a * x1 + b;
                    double y2Expected = a * x2 + b;
                    return Math.abs(y1 - y1Expected) < TOLERANCE && Math.abs(y2 - y2Expected) < TOLERANCE;
                }
            } else {
                if (isVertical) {
                    double expectedX = b;
                    return checkInequality(x1, expectedX, type) && checkInequality(x2, expectedX, type);
                } else if (isHorizontal) {
                    double expectedY = b;
                    return checkInequality(y1, expectedY, type) && checkInequality(y2, expectedY, type);
                } else {
                    double y1Expected = a * x1 + b;
                    double y2Expected = a * x2 + b;
                    return checkInequality(y1, y1Expected, type) && checkInequality(y2, y2Expected, type);
                }
            }
        }
    }

    private boolean checkInequality(double actual, double expected, String type) {
        switch (type) {
            case ">=": return actual >= expected - TOLERANCE;
            case "<=": return actual <= expected + TOLERANCE;
            case ">": return actual > expected + TOLERANCE;
            case "<": return actual < expected - TOLERANCE;
            default: return false;
        }
    }

    public boolean satisfiesPoint(double x, double y) {
        String effectiveType = type.isEmpty() ? detectedType : type;
        if (effectiveType.equals("=")) {
            if (isVertical) {
                return Math.abs(x - b) < TOLERANCE;
            } else if (isHorizontal) {
                return Math.abs(y - b) < TOLERANCE;
            } else {
                double yExpected = a * x + b;
                return Math.abs(y - yExpected) < TOLERANCE;
            }
        } else {
            if (isVertical) {
                return checkInequality(x, b, effectiveType);
            } else if (isHorizontal) {
                return checkInequality(y, b, effectiveType);
            } else {
                double yExpected = a * x + b;
                return checkInequality(y, yExpected, effectiveType);
            }
        }
    }

    public boolean hasXIntercept() {
        if (isVertical) return b == 0;
        if (isHorizontal) return b == 0;
        return !Double.isInfinite(-b / a);
    }

    public double getXIntercept() {
        if (!hasXIntercept()) return Double.NaN;
        if (isVertical && b == 0) return 0;
        if (isHorizontal && b == 0) return 0;
        return -b / a;
    }

    public boolean hasYIntercept() {
        return !isVertical;
    }

    public double getYIntercept() {
        if (!hasYIntercept()) return Double.NaN;
        return b;
    }

    public String getType() {
        return type.isEmpty() ? detectedType : type;
    }
}