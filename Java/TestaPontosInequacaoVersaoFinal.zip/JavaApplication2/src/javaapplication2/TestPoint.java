package javaapplication2;

import java.util.List;

public class TestPoint {
    double x, y;
    boolean[] satisfies;

    public TestPoint(double x, double y, int numLines) {
        this.x = x;
        this.y = y;
        this.satisfies = new boolean[numLines];
    }

    public void evaluateLines(List<Line> lines) {
        for (int i = 0; i < lines.size(); i++) {
            satisfies[i] = lines.get(i).satisfiesPoint(x, y);
        }
    }
}