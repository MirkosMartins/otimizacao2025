package javaapplication2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class LineManager {
    private List<Line> lines = new ArrayList<>();
    private List<Intersection> intersections = new ArrayList<>();
    private List<Intersection> firstQuadrantIntersections = new ArrayList<>();
    private LineVariation maxVariation = null;
    private static final String FILE_PATH;

    static {
        String userHome = System.getProperty("user.home");
        String os = System.getProperty("os.name").toLowerCase();
        String documentsFolder = os.contains("win") ? "Documents" : "Documentos";
        FILE_PATH = userHome + System.getProperty("file.separator") + documentsFolder +
                    System.getProperty("file.separator") + "input.txt";
    }

    public void initialize() {
        readLinesFromFile();
        findAllIntersections();
        findFirstQuadrantIntersections();
        findMaxLineVariation();
    }

    public List<Line> getLines() { return lines; }
    public List<Intersection> getIntersections() { return intersections; }
    public List<Intersection> getFirstQuadrantIntersections() { return firstQuadrantIntersections; }
    public LineVariation getMaxVariation() { return maxVariation; }

    private void readLinesFromFile() {
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.trim().split("\\s+");
                if (parts.length == 4 || parts.length == 5) {
                    int x1 = Integer.parseInt(parts[0].replace("(", "").replace(",", ""));
                    int y1 = Integer.parseInt(parts[1].replace(")", ""));
                    int x2 = Integer.parseInt(parts[2].replace("(", "").replace(",", ""));
                    int y2 = Integer.parseInt(parts[3].replace(")", ""));
                    String type = parts.length == 5 ? parts[4] : "";

                    lines.add(new Line(x1, y1, x2, y2, type));
                    Line addedLine = lines.get(lines.size() - 1);

                    if (addedLine.isVertical) {
                        System.out.println("Reta " + lines.size() + ": x " + addedLine.getType() + " " + String.format("%.2f", addedLine.b));
                    } else if (addedLine.isHorizontal) {
                        System.out.println("Reta " + lines.size() + ": y " + addedLine.getType() + " " + String.format("%.2f", addedLine.b));
                    } else {
                        System.out.println("Reta " + lines.size() + ": y " + addedLine.getType() + " " + String.format("%.2f", addedLine.a) +
                                           "x + " + String.format("%.2f", addedLine.b));
                    }

                    System.out.println("Pontos: (" + x1 + "," + y1 + ") e (" + x2 + "," + y2 + ")");
                    System.out.println("Interseção com eixo x: " + (addedLine.hasXIntercept() ?
                                           "(" + String.format("%.2f", addedLine.getXIntercept()) + ", 0)" : "Nenhuma"));
                    System.out.println("Interseção com eixo y: " + (addedLine.hasYIntercept() ?
                                           "(0, " + String.format("%.2f", addedLine.getYIntercept()) + ")" : "Nenhuma"));
                    System.out.println("Tipo da reta válido: " + addedLine.isTypeValid);
                    if (type.isEmpty()) {
                        System.out.println("Tipo detectado: " + addedLine.getType());
                    }
                }
            }
            System.out.println("\nTotal de retas encontradas: " + lines.size());
        } catch (IOException e) {
            System.err.println("Erro ao ler o arquivo: " + e.getMessage());
        }
    }

    private void findAllIntersections() {
        for (int i = 0; i < lines.size(); i++) {
            for (int j = i + 1; j < lines.size(); j++) {
                Line line1 = lines.get(i);
                Line line2 = lines.get(j);

                if (line1.isVertical && line2.isVertical) {
                    System.out.println("Retas " + (i + 1) + " e " + (j + 1) + (Math.abs(line1.b - line2.b) < 0.0001 ?
                                       " são coincidentes (verticais)." : " são paralelas (verticais)."));
                } else if (line1.isHorizontal && line2.isHorizontal) {
                    System.out.println("Retas " + (i + 1) + " e " + (j + 1) + (Math.abs(line1.b - line2.b) < 0.0001 ?
                                       " são coincidentes (horizontais)." : " são paralelas (horizontais)."));
                } else {
                    double x, y;
                    if (line1.isVertical) {
                        x = line1.b;
                        y = line2.isHorizontal ? line2.b : line2.a * x + line2.b;
                    } else if (line2.isVertical) {
                        x = line2.b;
                        y = line1.isHorizontal ? line1.b : line1.a * x + line1.b;
                    } else if (line1.isHorizontal) {
                        y = line1.b;
                        x = line2.a != 0 ? (y - line2.b) / line2.a : Double.NaN;
                    } else if (line2.isHorizontal) {
                        y = line2.b;
                        x = line1.a != 0 ? (y - line1.b) / line1.a : Double.NaN;
                    } else {
                        double a1 = line1.a, b1 = line1.b, a2 = line2.a, b2 = line2.b;
                        if (Math.abs(a1 - a2) < 0.0001) {
                            System.out.println("Retas " + (i + 1) + " e " + (j + 1) + (Math.abs(b1 - b2) < 0.0001 ?
                                               " são coincidentes." : " são paralelas."));
                            continue;
                        }
                        x = (b2 - b1) / (a1 - a2);
                        y = a1 * x + b1;
                    }
                    if (!Double.isNaN(x) && !Double.isNaN(y)) {
                        intersections.add(new Intersection(x, y, i, j));
                        System.out.println("Interseção entre reta " + (i + 1) + " e reta " + (j + 1) + ": (" +
                                           String.format("%.2f", x) + ", " + String.format("%.2f", y) + ")");
                    }
                }
            }
        }
        System.out.println("\nTotal de interseções encontradas: " + intersections.size());
    }

    private void findFirstQuadrantIntersections() {
        for (Intersection inter : intersections) {
            if (inter.x > 0 && inter.y > 0) {
                firstQuadrantIntersections.add(inter);
                System.out.println("Interseção no primeiro quadrante entre reta " + (inter.line1 + 1) +
                                   " e reta " + (inter.line2 + 1) + ": (" +
                                   String.format("%.2f", inter.x) + ", " + String.format("%.2f", inter.y) + ")");
            }
        }
        System.out.println("Total de interseções no primeiro quadrante: " + firstQuadrantIntersections.size());
    }

    private void findMaxLineVariation() {
        if (firstQuadrantIntersections.isEmpty()) {
            System.out.println("Nenhuma interseção no primeiro quadrante. Não há variação para calcular.");
            return;
        }

        Set<Integer> involvedLines = new HashSet<>();
        for (Intersection inter : firstQuadrantIntersections) {
            involvedLines.add(inter.line1);
            involvedLines.add(inter.line2);
        }

        double maxVar = -1;
        int maxVarLineIndex = -1;

        for (int lineIndex : involvedLines) {
            Line line = lines.get(lineIndex);
            double variation;

            if (line.isVertical) {
                if (line.b <= 0) continue;
                double minY = Double.MAX_VALUE, maxY = 0;
                for (Intersection inter : firstQuadrantIntersections) {
                    if (inter.line1 == lineIndex || inter.line2 == lineIndex) {
                        if (Math.abs(inter.x - line.b) < 0.0001) {
                            minY = Math.min(minY, inter.y);
                            maxY = Math.max(maxY, inter.y);
                        }
                    }
                }
                variation = (maxY > 0 && minY < Double.MAX_VALUE) ? maxY - minY : 0;
            } else if (line.isHorizontal) {
                if (line.b <= 0) continue;
                double minX = Double.MAX_VALUE, maxX = 0;
                for (Intersection inter : firstQuadrantIntersections) {
                    if (inter.line1 == lineIndex || inter.line2 == lineIndex) {
                        if (Math.abs(inter.y - line.b) < 0.0001) {
                            minX = Math.min(minX, inter.x);
                            maxX = Math.max(maxX, inter.x);
                        }
                    }
                }
                variation = (maxX > 0 && minX < Double.MAX_VALUE) ? maxX - minX : 0;
            } else {
                List<Double> yValues = new ArrayList<>();
                if (line.b > 0) yValues.add(line.b);
                for (Intersection inter : firstQuadrantIntersections) {
                    if (inter.line1 == lineIndex || inter.line2 == lineIndex) {
                    double expectedY = line.a * inter.x + line.b;
                    if (Math.abs(expectedY - inter.y) < 0.0001) yValues.add(inter.y);
                    }
                }
                double xAtY0 = -line.b / line.a;
                if (xAtY0 > 0) yValues.add(0.0);
                variation = yValues.isEmpty() ? 0 :
                        yValues.stream().max(Double::compare).get() - yValues.stream().min(Double::compare).get();
            }

            System.out.println("Variação da reta " + (lineIndex + 1) + " no primeiro quadrante: " +
                    String.format("%.2f", variation));

            if (variation > maxVar) {
                maxVar = variation;
                maxVarLineIndex = lineIndex;
            }
        }

        if (maxVarLineIndex >= 0) {
            maxVariation = new LineVariation(maxVarLineIndex, maxVar);
            System.out.println("Maior variação no primeiro quadrante: Reta " + (maxVarLineIndex + 1) +
                    " com variação " + String.format("%.2f", maxVar));
        } else {
            System.out.println("Nenhuma variação válida encontrada no primeiro quadrante.");
        }
    }
}