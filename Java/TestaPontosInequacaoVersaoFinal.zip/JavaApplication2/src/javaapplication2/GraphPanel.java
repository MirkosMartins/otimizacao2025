package javaapplication2;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class GraphPanel extends JPanel {
    private LineManager lineManager;
    private List<TestPoint> testPoints = new ArrayList<>();
    private double scale = 20;
    private int centerX, centerY, lastX, lastY;
    private JTextField pointInputField;
    private JButton submitPointButton;
    private JButton clearPointsButton;
    private JLabel statusLabel;
    private int scrollOffset = 0;
    private boolean[] sectionCollapsed = {false, false, false, false}; 
    private static final Color[] COLORS = {
            new Color(65, 105, 225), new Color(34, 139, 34), new Color(178, 34, 34),
            new Color(218, 165, 32), new Color(72, 61, 139), new Color(0, 139, 139),
            new Color(205, 92, 92), new Color(85, 107, 47), new Color(139, 69, 19)
    };
    private static final Color[] TEST_POINT_COLORS = {
            Color.MAGENTA, Color.CYAN, Color.ORANGE, Color.PINK, Color.GREEN
    };
    private static final int PANEL_WIDTH = 400;
    private static final int LINE_HEIGHT = 20;
    private static final int HEADER_HEIGHT = 30;
    private static final int SECTION_GAP = 15;
    private static final int SCROLL_INCREMENT = 10;
    private static final int BOTTOM_PADDING = 20;

    public GraphPanel(LineManager lineManager) {
        this.lineManager = lineManager;
        setLayout(null);
        initializeComponents();
        addListeners();
    }

    private void initializeComponents() {
        pointInputField = new JTextField("Ex: (x,y);(x,y)");
        pointInputField.setBounds(5, getHeight() - 65, 200, 25);
        pointInputField.setFont(new Font("Arial", Font.PLAIN, 14));
        pointInputField.setToolTipText("Digite pontos no formato (x,y);(x,y), ex: (1.5,2.0);(3.0,4.0)");
        pointInputField.setForeground(Color.GRAY);
        add(pointInputField);

        submitPointButton = new JButton("Testar Pontos");
        submitPointButton.setBounds(210, getHeight() - 65, 120, 25);
        submitPointButton.setFont(new Font("Arial", Font.BOLD, 12));
        submitPointButton.setBackground(new Color(50, 150, 50));
        submitPointButton.setForeground(Color.WHITE);
        submitPointButton.setFocusPainted(false);
        add(submitPointButton);

        clearPointsButton = new JButton("Limpar Pontos");
        clearPointsButton.setBounds(335, getHeight() - 65, 120, 25);
        clearPointsButton.setFont(new Font("Arial", Font.BOLD, 12));
        clearPointsButton.setBackground(new Color(200, 50, 50));
        clearPointsButton.setForeground(Color.WHITE);
        clearPointsButton.setFocusPainted(false);
        add(clearPointsButton);

        statusLabel = new JLabel("");
        statusLabel.setBounds(5, getHeight() - 35, 450, 25);
        statusLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        add(statusLabel);
    }

    private void addListeners() {
        pointInputField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (pointInputField.getText().equals("Ex: (x,y);(x,y)")) {
                    pointInputField.setText("");
                    pointInputField.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (pointInputField.getText().isEmpty()) {
                    pointInputField.setText("Ex: (x,y);(x,y)");
                    pointInputField.setForeground(Color.GRAY);
                }
            }
        });

        pointInputField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { validateInput(); }
            @Override
            public void removeUpdate(DocumentEvent e) { validateInput(); }
            @Override
            public void changedUpdate(DocumentEvent e) { validateInput(); }

            private void validateInput() {
                String text = pointInputField.getText().trim();
                if (text.equals("Ex: (x,y);(x,y)") || text.isEmpty()) {
                    pointInputField.setBorder(BorderFactory.createLineBorder(Color.GRAY));
                    statusLabel.setText("");
                    return;
                }

                boolean isValid = true;
                String[] pointStrings = text.split(";");
                for (String pointStr : pointStrings) {
                    pointStr = pointStr.trim();
                    if (!pointStr.matches("\\(\\s*-?\\d+\\.?\\d*\\s*,\\s*-?\\d+\\.?\\d*\\s*\\)")) {
                        isValid = false;
                        break;
                    }
                }
                pointInputField.setBorder(BorderFactory.createLineBorder(isValid ? Color.GREEN : Color.RED));
            }
        });

        submitPointButton.addActionListener(e -> {
            String input = pointInputField.getText().trim();
            if (input.equals("Ex: (x,y);(x,y)") || input.isEmpty()) {
                statusLabel.setText("Digite pelo menos um ponto.");
                statusLabel.setForeground(Color.RED);
                return;
            }

            try {
                List<TestPoint> newPoints = new ArrayList<>();
                String[] pointStrings = input.split(";");
                for (int i = 0; i < pointStrings.length; i++) {
                    String pointStr = pointStrings[i].trim();
                    if (!pointStr.matches("\\(\\s*-?\\d+\\.?\\d*\\s*,\\s*-?\\d+\\.?\\d*\\s*\\)")) {
                        throw new IllegalArgumentException("Ponto " + (i + 1) + " inválido: " + pointStr);
                    }
                    String cleanedPointStr = pointStr.replaceAll("\\s+", "");
                    String[] parts = cleanedPointStr.replace("(", "").replace(")", "").split(",");
                    double x = Double.parseDouble(parts[0]);
                    double y = Double.parseDouble(parts[1]);

                    TestPoint point = new TestPoint(x, y, lineManager.getLines().size());
                    point.evaluateLines(lineManager.getLines());
                    newPoints.add(point);
                }

                testPoints.addAll(newPoints);
                System.out.println("\nPontos de teste digitados:");
                for (TestPoint point : newPoints) {
                    System.out.println("(" + String.format("%.2f", point.x) + ", " +
                            String.format("%.2f", point.y) + "):");
                    boolean allSatisfied = true;
                    List<Integer> unsatisfiedLines = new ArrayList<>();
                    for (int i = 0; i < lineManager.getLines().size(); i++) {
                        if (!point.satisfies[i]) {
                            allSatisfied = false;
                            unsatisfiedLines.add(i + 1);
                        }
                    }
                    if (allSatisfied) {
                        System.out.println("Satisfaz a área das retas");
                    } else {
                        System.out.println("Não satisfaz: " + unsatisfiedLines.stream()
                                .map(n -> "Reta " + n)
                                .collect(java.util.stream.Collectors.joining(", ")));
                    }
                }
                statusLabel.setText(newPoints.size() + " ponto(s) adicionado(s) com sucesso!");
                statusLabel.setForeground(new Color(0, 150, 0));
                pointInputField.setText("");
                pointInputField.setBorder(BorderFactory.createLineBorder(Color.GRAY));
                repaint();
            } catch (Exception ex) {
                statusLabel.setText("Erro: " + ex.getMessage());
                statusLabel.setForeground(Color.RED);
                JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage(), "Entrada Inválida",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        clearPointsButton.addActionListener(e -> {
            testPoints.clear();
            System.out.println("\nPontos de teste limpos.");
            statusLabel.setText("Pontos de teste limpos.");
            statusLabel.setForeground(new Color(0, 150, 0));
            pointInputField.setText("");
            pointInputField.setBorder(BorderFactory.createLineBorder(Color.GRAY));
            repaint();
        });

        addMouseWheelListener(e -> {
            Point mousePoint = e.getPoint();
            if (mousePoint.x <= PANEL_WIDTH + 5) {
                scrollOffset += e.getWheelRotation() * SCROLL_INCREMENT;
                int maxPanelHeight = getHeight() - 75;
                int maxScroll = Math.max(0, getTotalContentHeight() - maxPanelHeight);
                scrollOffset = Math.min(Math.max(scrollOffset, 0), maxScroll);
            } else {
                scale = e.getWheelRotation() < 0 ? scale * 1.1 : scale / 1.1;
                scale = Math.max(scale, 1.0);
            }
            repaint();
        });

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                lastX = e.getX();
                lastY = e.getY();

                int y = e.getY() + scrollOffset;
                if (e.getX() >= 5 && e.getX() <= PANEL_WIDTH + 5) {
                    if (y >= 10 && y <= 40) sectionCollapsed[0] = !sectionCollapsed[0];
                    else if (y >= getLinesSectionEnd() + SECTION_GAP && y <= getLinesSectionEnd() + SECTION_GAP + HEADER_HEIGHT)
                        sectionCollapsed[1] = !sectionCollapsed[1];
                    else if (y >= getIntersectionsSectionEnd() + SECTION_GAP && y <= getIntersectionsSectionEnd() + SECTION_GAP + HEADER_HEIGHT)
                        sectionCollapsed[2] = !sectionCollapsed[2];
                    else if (y >= getFirstQuadrantSectionEnd() + SECTION_GAP && y <= getFirstQuadrantSectionEnd() + SECTION_GAP + HEADER_HEIGHT)
                        sectionCollapsed[3] = !sectionCollapsed[3];
                    repaint();
                }
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getButton() == MouseEvent.BUTTON1 && e.getX() > PANEL_WIDTH + 5) {
                    double x = (e.getX() - centerX) / scale;
                    double y = (centerY - e.getY()) / scale;
                    TestPoint point = new TestPoint(x, y, lineManager.getLines().size());
                    point.evaluateLines(lineManager.getLines());
                    testPoints.add(point);
                    System.out.println("\nPonto de teste selecionado: (" + String.format("%.2f", x) + ", " +
                            String.format("%.2f", y) + ")");
                    boolean allSatisfied = true;
                    List<Integer> unsatisfiedLines = new ArrayList<>();
                    for (int i = 0; i < lineManager.getLines().size(); i++) {
                        if (!point.satisfies[i]) {
                            allSatisfied = false;
                            unsatisfiedLines.add(i + 1);
                        }
                    }
                    if (allSatisfied) {
                        System.out.println("Satisfaz a área das retas");
                        statusLabel.setText("Ponto (" + String.format("%.2f", x) + "," + String.format("%.2f", y) +
                                ") adicionado: Satisfaz a área");
                    } else {
                        String unsatisfied = unsatisfiedLines.stream()
                                .map(n -> "Reta " + n)
                                .collect(java.util.stream.Collectors.joining(", "));
                        System.out.println("Não satisfaz: " + unsatisfied);
                        statusLabel.setText("Ponto (" + String.format("%.2f", x) + "," + String.format("%.2f", y) +
                                ") adicionado: Não satisfaz " + unsatisfied);
                    }
                    statusLabel.setForeground(new Color(0, 150, 0));
                    repaint();
                }
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                centerX += e.getX() - lastX;
                centerY += e.getY() - lastY;
                lastX = e.getX();
                lastY = e.getY();
                repaint();
            }
        });

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                pointInputField.setBounds(5, getHeight() - 65, 200, 25);
                submitPointButton.setBounds(210, getHeight() - 65, 120, 25);
                clearPointsButton.setBounds(335, getHeight() - 65, 120, 25);
                statusLabel.setBounds(5, getHeight() - 35, 450, 25);
            }
        });
    }

    private int getLinesSectionEnd() {
        return HEADER_HEIGHT + (sectionCollapsed[0] ? 0 : lineManager.getLines().size() * LINE_HEIGHT * 2) + 10;
    }

    private int getIntersectionsSectionEnd() {
        int start = getLinesSectionEnd() + SECTION_GAP + HEADER_HEIGHT;
        return start + (sectionCollapsed[1] ? 0 : lineManager.getIntersections().size() * LINE_HEIGHT);
    }

    private int getFirstQuadrantSectionEnd() {
        int start = getIntersectionsSectionEnd() + SECTION_GAP + HEADER_HEIGHT;
        return start + (sectionCollapsed[2] ? 0 : lineManager.getFirstQuadrantIntersections().size() * LINE_HEIGHT);
    }

    private int getTotalContentHeight() {
        int testPointLines = testPoints.isEmpty() ? 0 : testPoints.size() * 2; 
        return HEADER_HEIGHT + (sectionCollapsed[0] ? 0 : lineManager.getLines().size() * LINE_HEIGHT * 2) +
               SECTION_GAP + HEADER_HEIGHT + (sectionCollapsed[1] ? 0 : lineManager.getIntersections().size() * LINE_HEIGHT) +
               SECTION_GAP + HEADER_HEIGHT + (sectionCollapsed[2] ? 0 : lineManager.getFirstQuadrantIntersections().size() * LINE_HEIGHT) +
               SECTION_GAP + HEADER_HEIGHT + (sectionCollapsed[3] ? 0 : LINE_HEIGHT) +
               SECTION_GAP + (testPoints.isEmpty() ? 0 : HEADER_HEIGHT + testPointLines * LINE_HEIGHT) + BOTTOM_PADDING;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        if (centerX == 0 && centerY == 0) {
            centerX = getWidth() / 2;
            centerY = getHeight() / 2;
        }

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2d.setColor(Color.WHITE);
        g2d.fillRect(0, 0, getWidth(), getHeight());

        g2d.setColor(Color.BLACK);
        g2d.drawLine(0, centerY, getWidth(), centerY);
        g2d.drawLine(centerX, 0, centerX, getHeight());

        int tickSize = 5, interval = 5;
        for (int x = -(int)(centerX / scale); x <= (getWidth() - centerX) / scale; x += interval) {
            int xPos = centerX + (int)(x * scale);
            g2d.drawLine(xPos, centerY - tickSize, xPos, centerY + tickSize);
            if (x != 0) g2d.drawString(String.valueOf(x), xPos - 5, centerY + 20);
        }
        for (int y = -(int)(centerY / scale); y <= (getHeight() - centerY) / scale; y += interval) {
            int yPos = centerY - (int)(y * scale);
            g2d.drawLine(centerX - tickSize, yPos, centerX + tickSize, yPos);
            if (y != 0) g2d.drawString(String.valueOf(y), centerX + 10, yPos + 5);
        }
        g2d.drawString("0", centerX + 5, centerY + 15);

        double minX = -centerX / scale, maxX = (getWidth() - centerX) / scale;
        double minY = -(getHeight() - centerY) / scale, maxY = centerY / scale;

        for (int i = 0; i < lineManager.getLines().size(); i++) {
            Line line = lineManager.getLines().get(i);
            Color lineColor = COLORS[i % COLORS.length];
            g2d.setColor(lineColor);

            if (line.isVertical) {
                int screenX = centerX + (int)(line.b * scale);
                g2d.drawLine(screenX, 0, screenX, getHeight());
            } else if (line.isHorizontal) {
                int screenY = centerY - (int)(line.b * scale);
                g2d.drawLine(0, screenY, getWidth(), screenY);
            } else {
                int x1Screen = centerX + (int)(line.x1 * scale), y1Screen = centerY - (int)(line.y1 * scale);
                int x2Screen = centerX + (int)(line.x2 * scale), y2Screen = centerY - (int)(line.y2 * scale);
                g2d.setStroke(new java.awt.BasicStroke(2.5f));
                g2d.drawLine(x1Screen, y1Screen, x2Screen, y2Screen);

                double leftY = line.a * minX + line.b, rightY = line.a * maxX + line.b;
                int leftYScreen = centerY - (int)(leftY * scale), rightYScreen = centerY - (int)(rightY * scale);
                g2d.setStroke(new java.awt.BasicStroke(1.5f, java.awt.BasicStroke.CAP_BUTT,
                        java.awt.BasicStroke.JOIN_MITER, 10.0f, new float[]{8.0f, 4.0f}, 0.0f));
                g2d.setColor(new Color(lineColor.getRed(), lineColor.getGreen(), lineColor.getBlue(), 100));
                g2d.drawLine(0, leftYScreen, getWidth(), rightYScreen);
                g2d.setStroke(new java.awt.BasicStroke(1.0f));
            }

            int pointSize = 8;
            g2d.setColor(Color.WHITE);
            g2d.fillOval(centerX + (int)(line.x1 * scale) - pointSize/2, centerY - (int)(line.y1 * scale) - pointSize/2,
                    pointSize, pointSize);
            g2d.fillOval(centerX + (int)(line.x2 * scale) - pointSize/2, centerY - (int)(line.y2 * scale) - pointSize/2,
                    pointSize, pointSize);
            g2d.setColor(lineColor.darker());
            g2d.drawOval(centerX + (int)(line.x1 * scale) - pointSize/2, centerY - (int)(line.y1 * scale) - pointSize/2,
                    pointSize, pointSize);
            g2d.drawOval(centerX + (int)(line.x2 * scale) - pointSize/2, centerY - (int)(line.y2 * scale) - pointSize/2,
                    pointSize, pointSize);

            Font originalFont = g2d.getFont();
            g2d.setFont(new Font("Arial", Font.PLAIN, 10));
            g2d.setColor(Color.BLACK);
            g2d.drawString("(" + line.x1 + "," + line.y1 + ")", centerX + (int)(line.x1 * scale) + 5,
                    centerY - (int)(line.y1 * scale) - 5);
            g2d.drawString("(" + line.x2 + "," + line.y2 + ")", centerX + (int)(line.x2 * scale) + 5,
                    centerY - (int)(line.y2 * scale) - 5);
            g2d.setFont(originalFont);
        }

        int intersectSize = 10;
        for (Intersection inter : lineManager.getIntersections()) {
            int ix = centerX + (int)(inter.x * scale) - intersectSize/2;
            int iy = centerY - (int)(inter.y * scale) - intersectSize/2;
            if (ix >= -intersectSize && ix <= getWidth() + intersectSize && iy >= -intersectSize && iy <= getHeight() + intersectSize) {
                g2d.setColor(lineManager.getFirstQuadrantIntersections().contains(inter) ? Color.RED : Color.YELLOW);
                g2d.fillOval(ix, iy, intersectSize, intersectSize);
                g2d.setColor(Color.BLACK);
                g2d.drawOval(ix, iy, intersectSize, intersectSize);
                g2d.drawString("(" + String.format("%.1f", inter.x) + "," + String.format("%.1f", inter.y) + ")",
                        ix + intersectSize, iy);
            }
        }

        for (int i = 0; i < testPoints.size(); i++) {
            TestPoint point = testPoints.get(i);
            int pointSize = 12;
            int screenX = centerX + (int)(point.x * scale) - pointSize/2;
            int screenY = centerY - (int)(point.y * scale) - pointSize/2;
            g2d.setColor(TEST_POINT_COLORS[i % TEST_POINT_COLORS.length]);
            g2d.fillOval(screenX, screenY, pointSize, pointSize);
            g2d.setColor(Color.BLACK);
            g2d.drawOval(screenX, screenY, pointSize, pointSize);
            g2d.drawString("(" + String.format("%.2f", point.x) + "," + String.format("%.2f", point.y) + ")",
                    screenX + pointSize, screenY);
        }

        int maxPanelHeight = getHeight() - 75;
        int contentHeight = getTotalContentHeight();
        int actualPanelHeight = Math.min(contentHeight, maxPanelHeight);
        g2d.setClip(5, 5, PANEL_WIDTH, actualPanelHeight);

        g2d.setPaint(new GradientPaint(5, 5, new Color(245, 245, 245), 5, actualPanelHeight, new Color(220, 220, 220)));
        g2d.fillRoundRect(5, 5, PANEL_WIDTH, actualPanelHeight, 15, 15);
        g2d.setColor(new Color(150, 150, 150));
        g2d.drawRoundRect(5, 5, PANEL_WIDTH, actualPanelHeight, 15, 15);

        int currentY = 20 - scrollOffset;

        g2d.setColor(new Color(30, 30, 30));
        g2d.setFont(new Font("Arial", Font.BOLD, 16));
        g2d.drawString("Informações do Gráfico", 20, currentY);
        g2d.setColor(new Color(100, 100, 100));
        g2d.drawLine(15, currentY + 5, PANEL_WIDTH - 15, currentY + 5);
        currentY += HEADER_HEIGHT;

        if (!sectionCollapsed[0]) {
            g2d.setFont(new Font("Monospaced", Font.PLAIN, 12));
            for (int i = 0; i < lineManager.getLines().size(); i++) {
                Line line = lineManager.getLines().get(i);
                String eq = line.isVertical ? String.format("Reta %d: x %s %.2f", i + 1, line.getType(), line.b) :
                        line.isHorizontal ? String.format("Reta %d: y %s %.2f", i + 1, line.getType(), line.b) :
                                String.format("Reta %d: y %s %.2fx + %.2f", i + 1, line.getType(), line.a, line.b);
                if (currentY >= 10 && currentY < actualPanelHeight - 10) {
                    g2d.setColor(COLORS[i % COLORS.length]);
                    g2d.drawString(eq, 20, currentY);
                    g2d.setColor(line.isTypeValid ? new Color(0, 150, 0) : new Color(200, 0, 0));
                    g2d.drawString("✔ Tipo Válido: " + line.isTypeValid, 20, currentY + LINE_HEIGHT);
                }
                currentY += LINE_HEIGHT * 2;
            }
        }
        currentY += SECTION_GAP;

        g2d.setColor(new Color(30, 30, 30));
        g2d.setFont(new Font("Arial", Font.BOLD, 14));
        if (currentY >= 10 && currentY < actualPanelHeight - 10) {
            g2d.drawString(sectionCollapsed[1] ? "▶ Interseções" : "▼ Interseções", 20, currentY);
        }
        currentY += HEADER_HEIGHT;
        if (!sectionCollapsed[1]) {
            g2d.setFont(new Font("Monospaced", Font.PLAIN, 12));
            for (int i = 0; i < lineManager.getIntersections().size(); i++) {
                Intersection inter = lineManager.getIntersections().get(i);
                if (currentY >= 10 && currentY < actualPanelHeight - 10) {
                    g2d.setColor(Color.BLACK);
                    g2d.drawString(String.format("R%d ∩ R%d: (%.2f, %.2f)", inter.line1 + 1, inter.line2 + 1, inter.x, inter.y),
                            20, currentY);
                }
                currentY += LINE_HEIGHT;
            }
        }
        currentY += SECTION_GAP;

        g2d.setColor(new Color(30, 30, 30));
        g2d.setFont(new Font("Arial", Font.BOLD, 14));
        if (currentY >= 10 && currentY < actualPanelHeight - 10) {
            g2d.drawString(sectionCollapsed[2] ? "▶ Interseções 1º Quadrante" : "▼ Interseções 1º Quadrante", 20, currentY);
        }
        currentY += HEADER_HEIGHT;
        if (!sectionCollapsed[2]) {
            g2d.setFont(new Font("Monospaced", Font.PLAIN, 12));
            for (int i = 0; i < lineManager.getFirstQuadrantIntersections().size(); i++) {
                Intersection inter = lineManager.getFirstQuadrantIntersections().get(i);
                if (currentY >= 10 && currentY < actualPanelHeight - 10) {
                    g2d.setColor(Color.BLACK);
                    g2d.drawString(String.format("R%d ∩ R%d: (%.2f, %.2f)", inter.line1 + 1, inter.line2 + 1, inter.x, inter.y),
                            20, currentY);
                }
                currentY += LINE_HEIGHT;
            }
        }
        currentY += SECTION_GAP;

        g2d.setColor(new Color(30, 30, 30));
        g2d.setFont(new Font("Arial", Font.BOLD, 14));
        if (currentY >= 10 && currentY < actualPanelHeight - 10) {
            g2d.drawString(sectionCollapsed[3] ? "▶ Maior Variação" : "▼ Maior Variação", 20, currentY);
        }
        currentY += HEADER_HEIGHT;
        if (!sectionCollapsed[3]) {
            g2d.setFont(new Font("Monospaced", Font.PLAIN, 12));
            if (currentY >= 10 && currentY < actualPanelHeight - 10) {
                if (lineManager.getMaxVariation() != null) {
                    g2d.setColor(COLORS[lineManager.getMaxVariation().lineIndex % COLORS.length]);
                    g2d.drawString(String.format("R%d: %.2f", lineManager.getMaxVariation().lineIndex + 1,
                            lineManager.getMaxVariation().variation), 20, currentY);
                } else {
                    g2d.setColor(Color.BLACK);
                    g2d.drawString("Nenhuma variação válida", 20, currentY);
                }
            }
            currentY += LINE_HEIGHT;
        }
        currentY += SECTION_GAP;

        if (!testPoints.isEmpty()) {
            g2d.setColor(new Color(30, 30, 30));
            g2d.setFont(new Font("Arial", Font.BOLD, 14));
            if (currentY >= 10 && currentY < actualPanelHeight - 10) {
                g2d.drawString("Pontos de Teste", 20, currentY);
            }
            currentY += HEADER_HEIGHT;
            g2d.setFont(new Font("Monospaced", Font.PLAIN, 12));
            for (int i = 0; i < testPoints.size() && currentY < actualPanelHeight - 10; i++) {
                TestPoint point = testPoints.get(i);
                if (currentY >= 10) {
                    g2d.setColor(TEST_POINT_COLORS[i % TEST_POINT_COLORS.length]);
                    g2d.drawString(String.format("P%d: (%.2f, %.2f)", i + 1, point.x, point.y), 20, currentY);
                }
                currentY += LINE_HEIGHT;
                if (currentY >= 10 && currentY < actualPanelHeight - 10) {
                    boolean allSatisfied = true;
                    List<Integer> unsatisfiedLines = new ArrayList<>();
                    for (int j = 0; j < lineManager.getLines().size(); j++) {
                        if (!point.satisfies[j]) {
                            allSatisfied = false;
                            unsatisfiedLines.add(j + 1);
                        }
                    }
                    if (allSatisfied) {
                        g2d.setColor(new Color(0, 150, 0));
                        g2d.drawString("Satisfaz a área das retas", 20, currentY);
                    } else {
                        g2d.setColor(new Color(200, 0, 0));
                        String unsatisfied = unsatisfiedLines.stream()
                                .map(n -> "Reta " + n)
                                .collect(java.util.stream.Collectors.joining(", "));
                        g2d.drawString("Não satisfaz: " + unsatisfied, 20, currentY);
                    }
                }
                currentY += LINE_HEIGHT;
            }
        }

        if (contentHeight > actualPanelHeight) {
            int scrollbarHeight = (int)((float)actualPanelHeight / contentHeight * actualPanelHeight);
            int scrollbarY = 5 + (int)((float)scrollOffset / contentHeight * (actualPanelHeight - scrollbarHeight));
            g2d.setColor(new Color(150, 150, 150, 150));
            g2d.fillRoundRect(PANEL_WIDTH - 10, scrollbarY, 8, scrollbarHeight, 8, 8);
        }

        g2d.setClip(null);
    }
}