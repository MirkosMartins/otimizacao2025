package javaapplication2;

import javax.swing.JFrame;

public class CruzamentoRetasPontos_OO {
    public static void main(String[] args) {
        LineManager lineManager = new LineManager();
        lineManager.initialize();

        JFrame frame = new JFrame("Gráfico das Retas com Interseções");
        GraphPanel panel = new GraphPanel(lineManager);
        frame.add(panel);
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}