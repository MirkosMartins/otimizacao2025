package javaapplication2;

public class Intersection {
    double x, y;
    int line1, line2;

    public Intersection(double x, double y, int line1, int line2) {
        this.x = x;
        this.y = y;
        this.line1 = line1;
        this.line2 = line2;
    }
}