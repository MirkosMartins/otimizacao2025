/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author laboratorio
 */
public class CruzamentoTeste_Arthur {
    private static final String FILE_PATH;
    private static final Random random = new Random();

    static {
        String userHome = System.getProperty("user.home");
        String os = System.getProperty("os.name").toLowerCase();
        String documentsFolder = os.contains("win") ? "Documents" : "Documentos";
        FILE_PATH = userHome + System.getProperty("file.separator") + documentsFolder + System.getProperty("file.separator") + "input.txt";
    }

    static class Line {
        int x1, y1, x2, y2;
        double a, b;

        Line(int x1, int y1, int x2, int y2) {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
            if (x2 != x1) {
                this.a = (double)(y2 - y1) / (x2 - x1);
                this.b = y1 - this.a * x1;
            } else {
                this.a = Double.POSITIVE_INFINITY;
                this.b = x1;
            }
        }
    }


    static class Intersection {
        double x, y;
        int line1, line2;

        Intersection(double x, double y, int line1, int line2) {
            this.x = x;
            this.y = y;
            this.line1 = line1;
            this.line2 = line2;
        }
    }


    static class LineIntersectionCalculator {
        public List<Line> readLinesFromString(String input) {
            List<Line> lines = new ArrayList<>();
            String[] inputLines = input.split("\n");
            for (String line : inputLines) {
                String[] parts = line.trim().split("\\s+");
                if (parts.length == 4) {
                    int x1 = Integer.parseInt(parts[0].replace("(", "").replace(",", ""));
                    int y1 = Integer.parseInt(parts[1].replace(")", ""));
                    int x2 = Integer.parseInt(parts[2].replace("(", "").replace(",", ""));
                    int y2 = Integer.parseInt(parts[3].replace(")", ""));
                    lines.add(new Line(x1, y1, x2, y2));
                }
            }
            return lines;
        }

        public List<Intersection> findAllIntersections(List<Line> lines) {
            List<Intersection> intersections = new ArrayList<>();
            for (int i = 0; i < lines.size(); i++) {
                for (int j = i + 1; j < lines.size(); j++) {
                    Line line1 = lines.get(i);
                    Line line2 = lines.get(j);

                    if (line1.x1 == line1.x2 && line2.x1 == line2.x2) {
                        continue; 
                    } else if (line1.x1 == line1.x2) {
                        double x = line1.x1;
                        double y = line2.a * x + line2.b;
                        intersections.add(new Intersection(x, y, i, j));
                    } else if (line2.x1 == line2.x2) {
                        double x = line2.x1;
                        double y = line1.a * x + line1.b;
                        intersections.add(new Intersection(x, y, i, j));
                    } else {
                        double a1 = line1.a, b1 = line1.b;
                        double a2 = line2.a, b2 = line2.b;

                        if (Math.abs(a1 - a2) < 0.0001) {
                            continue; 
                        } else {
                            double x = (b2 - b1) / (a1 - a2);
                            double y = a1 * x + b1;
                            intersections.add(new Intersection(x, y, i, j));
                        }
                    }
                }
            }
            return intersections;
        }
    }

    public static void main(String[] args) {
        List<Line> generatedLines = generateRandomInputFile(5); 
        List<Intersection> expectedIntersections = calculateExpectedIntersections(generatedLines);

        LineIntersectionCalculator calculator = new LineIntersectionCalculator();
        StringBuilder inputContent = new StringBuilder();
        for (Line line : generatedLines) {
            inputContent.append(String.format("(%d, %d) (%d, %d)\n", line.x1, line.y1, line.x2, line.y2));
        }
        List<Line> calcLines = calculator.readLinesFromString(inputContent.toString());
        List<Intersection> calculatedIntersections = calculator.findAllIntersections(calcLines);

        verifyIntersections(expectedIntersections, calculatedIntersections);

        CruzamentoRetasTxt_Arthur.main(new String[]{});
    }

    private static List<Line> generateRandomInputFile(int numLines) {
        List<Line> lines = new ArrayList<>();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (int i = 0; i < numLines; i++) {
                int x1 = random.nextInt(21) - 10; 
                int y1 = random.nextInt(21) - 10;
                int x2, y2;
                do {
                    x2 = random.nextInt(21) - 10;
                    y2 = random.nextInt(21) - 10;
                } while (x1 == x2 && y1 == y2); 
                lines.add(new Line(x1, y1, x2, y2));
                writer.write(String.format("(%d, %d) (%d, %d)\n", x1, y1, x2, y2));
                System.out.printf("Reta %d gerada: (%d, %d) (%d, %d)\n", i + 1, x1, y1, x2, y2);
            }
            System.out.println("Arquivo input.txt gerado com sucesso em: " + FILE_PATH);
        } catch (IOException e) {
            System.err.println("Erro ao gerar o arquivo input.txt: " + e.getMessage());
        }
        return lines;
    }

    private static List<Intersection> calculateExpectedIntersections(List<Line> lines) {
        List<Intersection> intersections = new ArrayList<>();
        for (int i = 0; i < lines.size(); i++) {
            for (int j = i + 1; j < lines.size(); j++) {
                Line line1 = lines.get(i);
                Line line2 = lines.get(j);

                if (line1.x1 == line1.x2 && line2.x1 == line2.x2) {
                    continue; 
                } else if (line1.x1 == line1.x2) {
                    double x = line1.x1;
                    double y = line2.a * x + line2.b;
                    intersections.add(new Intersection(x, y, i, j));
                } else if (line2.x1 == line2.x2) {
                    double x = line2.x1;
                    double y = line1.a * x + line1.b;
                    intersections.add(new Intersection(x, y, i, j));
                } else {
                    double a1 = line1.a, b1 = line1.b;
                    double a2 = line2.a, b2 = line2.b;

                    if (Math.abs(a1 - a2) < 0.0001) {
                        continue; 
                    } else {
                        double x = (b2 - b1) / (a1 - a2);
                        double y = a1 * x + b1;
                        intersections.add(new Intersection(x, y, i, j));
                    }
                }
            }
        }
        System.out.println("Intersecoes esperadas calculadas: " + intersections.size());
        for (Intersection inter : intersections) {
            System.out.printf("Esperado: R%d ∩ R%d: (%.2f, %.2f)\n", inter.line1 + 1, inter.line2 + 1, inter.x, inter.y);
        }
        return intersections;
    }

    private static void verifyIntersections(List<Intersection> expected, List<Intersection> calculated) {
        System.out.println("\nVerificando intersecoes...");
        System.out.println("Intersecoes calculadas: " + calculated.size());
        for (Intersection inter : calculated) {
            System.out.printf("Calculado: R%d ∩ R%d: (%.2f, %.2f)\n", inter.line1 + 1, inter.line2 + 1, inter.x, inter.y);
        }

        if (expected.size() != calculated.size()) {
            System.out.println("Erro: Número de intersecoes esperadas (" + expected.size() + 
                               ") difere do calculado (" + calculated.size() + ")");
            return;
        }

        boolean allMatch = true;
        for (Intersection exp : expected) {
            boolean found = false;
            for (Intersection calc : calculated) {
                if (Math.abs(exp.x - calc.x) < 0.0001 && Math.abs(exp.y - calc.y) < 0.0001 &&
                    exp.line1 == calc.line1 && exp.line2 == calc.line2) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                allMatch = false;
                System.out.printf("Erro: Intersecao esperada R%d ∩ R%d: (%.2f, %.2f) nao encontrada\n", 
                                  exp.line1 + 1, exp.line2 + 1, exp.x, exp.y);
            }
        }

        if (allMatch) {
            System.out.println("Sucesso: Todas as intersecoes calculadas correspondem as esperadas!");
        } else {
            System.out.println("Falha: Algumas intersecoes nao correspondem às esperadas.");
        }
    }    
}
